Quayzen design kit (November 2026)

icons/            Four packs, 32 icons each, 120 x 120 SVG:
                  pencil-light, pencil-dark (light ink for dark backgrounds),
                  professional-light, professional-dark (iOS-style tiles; same art in both modes).
                  Professional symbols: Phosphor Icons, MIT licence (see LICENSE-phosphor.txt).
logo/             Pencil logo (light and dark), pencil and professional ring marks,
                  professional wordmark (light and dark; uses the Space Grotesk font if installed).
                  Pencil wordmark lettering: Kalam Bold, SIL Open Font Licence, converted to outlines.
illustrations/    Colombo skyline sketch and SEZ waterfront drawing, light and dark.
overview-sheets/  One sheet per icon pack showing every icon with its name.
layouts/          Main screens in all four modes (sign-in, dashboard, charts, reports, menu).
                  These are full-resolution screenshots placed inside SVG files, not editable vectors.
